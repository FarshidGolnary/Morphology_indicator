function classificationtask (reduced_data,Betti_count,cluster_num,Coeff,microstructure_num, Data_num_class) 
% This function requires 5 inputs:
% 1. reduced_data: A matrix containing images whose dimensions have been reduced by the PCA algorithm.
% 2. Betti_count: An array consisting of the corresponding first Betti numbers for each microstructure.
% 3. cluster_num: The number of clusters for the k-means algorithm.
% 4. microstructure_num: The total number of microstructures for which the morphology index will be calculated.
% 5. Data_num_class: The total number of microstructures used for the classification task.
% Output: The variable "Data_all" will be stored in the specified directory as the output.
j=1; %"j" is the counter of microstructural segments
[k,c]=kmeans(reduced_data,cluster_num); % The k-means algorithm partitions the reduced_data into clusters based on their similarity.
net=fitcnet(R_d,k); % A classifier is trained to determine the class of the microstructural segment. 
Data_all=zeros(microstructure_num,max(Betti_count(:)));% Data_all is a matrix used to store the indices of all the microstructural sections.
% The number of its rows equals the number of sections, and the number of columns equals the maximum Betti number among the microstructures.
% All microstructural index IDs are stored in the Data_all variable.

%% In this section, the images are called from the directory
while (exist (['image',num2str(Data_num_class),'_',num2str(j),'.jpg'])==2)
    while (exist (['image',num2str(Data_num_class),'_',num2str(j),'.jpg'])==2) || j<Betti_count(i)+1
        if exist (['image',num2str(Data_num_class),'_',num2str(j),'.jpg'])==2
         I=['image',num2str(Data_num_class),'_',num2str(j),'.jpg'];
         I=im2double(imread(I)); % The image is converted to double format
         I=I(:)'*Coeff; % The size of the called image is reduced by multiplying by the trunscated principal components.
         Data_all(Data_num_class,j)=predict(net,I); % The index is now predicted using the trained classifier
        end
        j=j+1;
    end
    disp(Data_num_class)
    if mod(Data_num_class,1000)==0
        save('Data_all',Data_all,k,c)
    end
    j=1;
    Data_num_class=Data_num_class+1;
end

