function imageextracter(data,Tr,P,counter)

    % This function is used for two objectives: first decomposing the
    % microstructures into segments based on their connectivity, second, converting them to images and then saving them as "jpg" format in disk memory. 
    %% Inputs: This function has four inputs: 1. data, which is a binary array that represents the porous microstructure. 2. Tr, which represents the Delaunay triangulation representation of the microstructural points. 3. P, which denotes the points coordinates in the microstructure. 4. counter: which notes the number of the microstructure. Counter is used to save the images with the mictostructure name. 
   
    %% b1 and b2 and b3 are notes that if a point in the triangular is void or solid 
    b1=data(Tr(:,1));
    b2=data(Tr(:,2));
    b3=data(Tr(:,3));
    b=[b1,b2,b3];
    s=sum(b,2); % If s<2, most or all of the triangle is placed on the void phase, therefore they are excluded from the whole triangulation representation. 
    L=find(s<2);
    Tr(L,:)=[];
    T=triangulation(Tr,P); % The new triangulation version of the microstructure based on the void-solid intraction is constructed.
    N=neighbors(T); % N denotes the neighbors of each trianular element.
    m=length(Tr);
    A=my_union(1,N); % A shows all the triangles that are connected to each other. A is calculated based on union-find algorithm in my_union function 
    %% This part create a triangular representation of the first disjoint region. In the next stage, an image will be created and saved.
    T=Tr(A,:);
     %x=rand(1,3);
    T=triangulation(T,P);
    if length(A)>1
    fig=figure();
        triplot(T);
        box off
        axis off
        print(fig, 'myfigure.jpg', '-djpeg', '-r50', '-noui', '-painters'); % The plot is saves in the directory in "jpg" format
        I=imread('myfigure.jpg'); % the saved plot is called 
        I=rgb2gray(I);%The plot is converted to a grayscale image
        close all
        connect=1;
        CC=['image',num2str(counter),'_',num2str(connect),'.jpg'];
        imwrite(I,CC); % The constructed graysale image is saved in the directory 
    end
    L=length(A);
    i=2;
    while (i~=m)
    num=any(A==i);
    if num==0
        B=my_union(i,N); % The disjoint region which is found by the union-find algorithm
        %% Note: This part was used for plotting different disjoint sections. The created image will be saved in disk memory and will be used for further processing
         T=Tr(B,:); % This variable denotes the connectivity matrix triangular representation of a disjoint region.
         T=triangulation(T,P); % variable T construct a triangular representation based on the connectivity matrix "T", and vertices matrix "P"
         connect=connect+1; % This variable counts the number of regions
         if length(B)>1
             fig=figure();
             triplot(T);
             box off
             axis off
             print(fig, 'myfigure.jpg', '-djpeg', '-r50', '-noui', '-painters'); % The plot is saves in the directory in "jpg" format
             I=imread('myfigure.jpg'); % the saved plot is called 
             I=rgb2gray(I); %The plot is converted to a grayscale image
             close all
             CC=['image',num2str(counter),'_',num2str(connect),'.jpg'];
             imwrite(I,CC); % The constructed graysale image is saved in the directory 
         end
         A=union(A,B); % Variable "A" stores all the disjoint regions
    end
    i=i+1;
    end
end
        
       
       
        