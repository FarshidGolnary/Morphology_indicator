function Out=imageorganizer(Betti_count, Image_size,Total_images_numbers, Tol)
% This function aims to reduce the dimensions of stored microstructural images using Principal Component Analysis (PCA). Initially, the microstructural images are loaded, followed by PCA to reduce their dimensions.
% The number of independent regions (referred to as "Betti_count" in this function) is determined by the first Betti number in a microstructure, a well-known topological invariant. The method for computing the Betti numbers has been previously discussed in our work (Golnary, Farshid, and Mohsen Asghari. "Investigating the influence of topology on elastic properties in spinodal microstructures." Modelling and Simulation in Materials Science and Engineering 32.1 (2023): 015006).
% Inputs: This function requires four inputs:
% 1. Betti_count: Represents the number of independent regions in the microstructure.
% 2. Image_size: Denotes the length of the microstructural images.
% 3. Total_images_numbers: Indicates the total number of microstructural images to be processed.
% 4. Tol: Represents the accuracy of the PCA algorithm, ranging between 0 and 1.

% Output: This function produces only one output. The variable "out" represents the truncated principal components, utilized for reducing the data dimensions.

i=1;  % "i" is a counter which denoted the number of microstructure.
j=1;  % "j" is a counter which counts the number of segments in a microstructure. For example, if a microstructure contains 34 independent segments, then j is 34.


Data=zeros(Image_size,Total_images_numbers); % The variable "Data" is a matrix that stores all the images.

connect=1; % Connect counts the number of microstructural segments. It is different from "i". Because "i" counts the total number of images whether they are existed in the directory or not. However, connect, counts only existing images in the directory.

%% In this part, the saved images in the directory are called, and then are stored in the "Data" matrix
while (exist (['image',num2str(i),'_',num2str(j),'.jpg'])==2)
    while (exist (['image',num2str(i),'_',num2str(j),'.jpg'])==2) || j<Betti_count(i)+1
        if exist (['image',num2str(i),'_',num2str(j),'.jpg'])==2
        I=['image',num2str(i),'_',num2str(j),'.jpg'];
        I=imread(I);
        I=I(:);
        Data(:,connect)=I;
        connect=connect+1;
        if connect>Total_images_numbers
            break
        end
        end
        j=j+1;
    end
    if connect>Total_images_numbers
       break
     end
    j=1;
    i=i+1;
end
Data=Data';
Data=im2double(Data); % Images are converted to double format

%% In this part PCA is implemented to reduce the dimensions of the images
Data=zscore(Data);
[coeff,~,latent,~] = pca(Data);
C=cumsum(latent)./sum(latent);
m=find(C>=Tol,1,'first');
Out=coeff(:,1:m); % Out is the principal components which can be used to reduce the data dimensions.
reduced_data=Data*coeff(:,1:m);
save("reduced_data","reduced_data")