%This function utilizes the union-find algorithm to identify disjoint regions within a specified representative volume element.
%This function takes two inputs:
%"i": The ID of a triangle.
%"N": A matrix containing the neighbors of all triangles.
function A=my_union(i,N)
C=N(i,:); % This variable denotes all the neighbors of the triangle with index "i"
C=C(~isnan(C)); % The "Nan" variables are removed
Lp=length(C);
A=union(i,C); % A denotes all the neibours along with triangular element "i"
L=length(A);
%% This process iterates continuously until the number of connected points remains unchanged.
while (Lp~=L)
    Lp=length(A);
    A=union(A,N(A,:));
    A=A(~isnan(A));
    L=length(A);
end
    
    