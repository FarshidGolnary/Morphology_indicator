% This function generates a two-dimensional spinodal topology..
% This function takes five inputs:
% "N": Number of standing waves.
% "L": Length of the representative volume element.
% "threshold": Threshold required for the level-set threshold method.
% "Lambda": Wavenumber.
% "dx": Grid size.
function topology=spinodaltopologycreator(N,L,threshold,lambda)
s=dx;
psi=zeros(L/dx+1,L/dx+1); %psi is the phase field value
[x,y]=meshgrid(0:s:L,0:s:L);
n=randn(N,2); % n is the wave vector value, which is uniformly distributed on the unit sphere surface
for i=1:N
    n(i,:)=n(i,:)/norm(n(i,:));
end
phi=2*pi*rand(N,1); % phi is the phase shifts of the standing waves which is uniformly distributed between zero and 2pi
for i=1:L/dx+1
    for j=1:L/dx+1
        psi(i,j)=sqrt(2/N)*sum(cos(sum(lambda*n.*repmat([x(i,j),y(i,j)],N,1),2)+phi)); % psi is computed based on Gaussian Random Field (GRF)
    end
end
topology=psi<threshold; % The topology is created via level set method.
end